<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Fortune Group LLC - Monitization</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta name="description" content="Fortune Group LLC: Your Trusted Loan Partner Looking for reliable financial assistance? Look no further than Fortune Group LLC. As a leading loan company, we specialize in providing tailored loan solutions to meet your unique needs. Whether you're planning to expand your business, consolidate debts, or fulfill personal aspirations, our team of experts is here to support you.With Fortune Group LLC, you can expect competitive interest rates, flexible repayment terms, and a hassle-free application process. We understand the value of your time, which is why we strive to deliver quick loan approvals, ensuring you get the funds you need when you need them.
" />

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500;600;700&family=Open+Sans:wght@400;500&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;"></div>
    </div>
    <!-- Spinner End -->


    <?php include 'header.php'; ?>

        <!-- Page Header Start -->
    <div class="container-fluid page-header mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container">
            <h1 class="display-3 mb-4 animated slideInDown"> Monitization</h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                   
                    <li class="breadcrumb-item active" aria-current="page"> Monitization</li>
                </ol>
            </nav>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- Bank Start -->
    <div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container text-center">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    
                    <h1 class="display-1">Monitization</h1>
                    <h1 class="mb-6">Leased Bank Instrument Monetization Myth</h1>
                    <p class="mb-6">When you need to monetize a financial instrument to fund your project, you can call one of our finance business consultants. We have the knowledge and expertise to monetize any financial instrument for your project’s funding.

We get emails from some “broker” who tell us you cannot monetize a Leased Bank Instruments eg A Leased Bank Guarantee, a Leased Standby Letter of Credit or a Leased MTN,

Their logic is a Leased Bank Instrument is NOT an Asset and therefore it CANNOT be monetized! Black and White, its just that simple they say!

The issue is they are 100% CORRECT that a Leased Bank Instrument is NOT an asset, just like a Leased car is NOT an asset. But they are 100% WRONG about Monetization.

The Truth is a Leased Bank Instrument can be monetized but not because it is an asset… because its not an asset! A Leased Bank Instrument can be monetized because the Lease (just like a car lease) is…. “The right to use the asset for a predetermined period of time.”<br>

And that Leased Bank Instrument right to use the asset for a predetermined period of Time:<br>

<ul>
    <li>Has Value</li>
    <li> Can be used by Monetizers to create a Profit (which pays for Monetization)</li>
</ul>

<blockquote>It is unfortunate that some people have such closed minds and are often so determined to prove themselves right that they don’t open themselves up to being able to learn something that they do not currently know. So we thought we would write this article to do a little wholesome educating while at the same time putting to bed the Myth that Leased Bank Instruments cannot be monetized.</blockquote>
</p>

<p> <strong>OUR PROCEDURES</strong><br>

    <ul class="list-check-icon">
                                <li>The Lender (We) shall carry our Financial, Corporate and Due diligence
investigations on the Debtor’s company after the successful investigation,
authenticity of the Debtor’s company and identification by our Legal Department, The Lender and Debtor execute, sign and initial this Deed of Agreement, which thereby automatically becomes a full commercial recourse contract to be lodged by both parties for initiation of Swift Transmission.</li>

<li>Within Seven (7) Banking Days after both parties sign the Agreement, Lender will issue a signed and sealed Corporate Refund Recourse Undertaking duly endorsed by the Lender’s bank to the Debtor guarantying to refund to the Debtor all cost incurred by Debtor as the Bank Transmission, Administrative &amp; Handling charges for the transmission of Non-Recourse Loan via Swift MT103 after due execution of the contract, and In case of failure on the Lender&#39;s side the signed and sealed Corporate Refund Recourse Undertaking guarantees that the Lender refunds
completely the Bank Transmission, Administrative &amp; Handling charges in addition to a the penalty for failure of performance being 1% of the Total Face Value of the Non-Recourse Loan.</li>

<li>Within One (1) Banking day after the Debtor receives from the Lender, the
Countersigned Contract alongside the signed and sealed Corporate Refund
Recourse Undertaking and countersigned Contract, the Debtor will make payment of the Bank Transmission, Administrative &amp; Handling charges for the Non-Recourse Loan via Swift MT103 by direct wire transfer into the Lender’s provided Banking Coordinates to receive Fees in the amount of Euro/USD XX,000.00.</li>

<li>Within Three (3) banking days after confirmation of receipt of payment of the Bank Transmission, Administrative & Handling charges for Non-Recourse Loan via Swift MT103 in Lender’s nominated bank account, the Lender will wire transfer Non- Recourse Loan via Bank to Bank confirmation of Swift MT103 to the Debtor’s Provided Bank Coordinate.</li>

<li>Debtor sends out Loan fees 3% LTV of by Swift MT103 to the Lender deducting the initially paid Bank Transmission, Administrative & Handling charges by wire transfer within Thirty (30) days upon confirmation of Non-Recourse Loan by MT103 in the Debtor’s nominated Bank account.

</li>

<li>Should the Debtor not deduct Bank Transmission, Administrative & Handling charges from loan 3% LTV fees paid, the Lender shall refund bank charges to Debtor by direct wire transfer within three (3) banking days upon payment of the Loan fees.</li>
                            </ul>
    
</p>
                    


                    <!--<a class="btn btn-primary py-3 px-5" href="">Go Back To Home</a>-->
                </div>
            </div>
        </div>
    </div>
    <!-- bank End -->

    <?php include 'footer.php'; ?>

    <?php include 'script.php'; ?>