<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Fortune Group LLC - Bank Proof Of Funds</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta name="description" content="Fortune Group LLC: Your Trusted Loan Partner Looking for reliable financial assistance? Look no further than Fortune Group LLC. As a leading loan company, we specialize in providing tailored loan solutions to meet your unique needs. Whether you're planning to expand your business, consolidate debts, or fulfill personal aspirations, our team of experts is here to support you.With Fortune Group LLC, you can expect competitive interest rates, flexible repayment terms, and a hassle-free application process. We understand the value of your time, which is why we strive to deliver quick loan approvals, ensuring you get the funds you need when you need them.
" />

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500;600;700&family=Open+Sans:wght@400;500&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;"></div>
    </div>
    <!-- Spinner End -->


    <?php include 'header.php'; ?>

        <!-- Page Header Start -->
    <div class="container-fluid page-header mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container">
            <h1 class="display-3 mb-4 animated slideInDown"> Bank Proof Of Funds</h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                   
                    <li class="breadcrumb-item active" aria-current="page"> Bank Proof Of Funds</li>
                </ol>
            </nav>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- Bank Start -->
    <div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container text-center">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    
                    <h1 class="display-1">Bank Proof Of Funds</h1>
                    <h1 class="mb-6">Bank Proof Of Funds</h1>
                    <p class="mb-6">Bank Proof of Funds (POF) are used for many different reasons, and they are a good source of financing for project finance, global finance, trade finance, and even credit enhancement. The funds are available for you, but you must know where to look and have someone broker the deal for you. A traditional POF is hard to come by because you need the cash fund of a large investor. However, you can bypass this through a Leased POF. With this innovative bank instrument, you can access someone else leased POF for a small fee and term. When the term is up, the account is returned, or the contract is extended. The owner will either create joint ownership or transfer it so that the ownership of the account is never a problem. This asset is available to the new owner for a period, and as the acting owner, they can lien, monetize, collateralize, or encumber the assets to suit their needs.</p>

                    <p><strong>Leased Bank Proof of Funds (POF)</strong></p>
<p class="sub-text-career">We use our relationships with partners at many Top Institutions, and we can help you find the perfect account for your Proof of Funds (POF).</p>
<p class="sub-text-career">1M is the minimum amount you can secure as USD or EUR through the MT199 or MT999. These fees are generally for a term of 90 days, and fees range between four and six percent. If a lower amount is desired, they will not use the MT999 or MT199.</p>
<p><strong>If no Swift is necessary, we can offer a rate of only 1,5% for a three-month term with a Hard Copy.</strong></p>
<p><strong>We Protect Our Client Deposits Fully Through 3 Levels of Protection</strong></p>
<p class="sub-text-career">You never have to worry about your security with our three levels of protection:</p>
<ol>
<li><strong>A Two Percent (2%) Non-Performance Penalty</strong>
<ul>
<li>Two Percent (2%) damage fee will apply to a Party that fails to perform. The 2% shall apply in both cases, either when the Provider has sent a Corporate Invoice which the Beneficiary’s Bank will not respond or pay, and/or when the Beneficiary’s Bank is ready, willing, and able to receive the BANK INSTRUMENTS and no BANK INSTRUMENTS is delivered from the Providers Bank by SWIFT MT-760, DTC, Euroclear or Bloomberg.</li>
</ul>
</li>
<li><strong>A Program to Refund Deposits</strong> (all our agreements are Bank Endorsed (<strong>confirmable</strong>) with full bank responsibility as an insurance wrap)
<ul>
<li>With our agreement with banks, that bank becomes responsible for payment when the transaction becomes complete.</li>
<li>When a bank endorsed an agreement, the bank becomes responsible before the client pays our company any fees. We are the only Bank Instrument Facilitators in the <strong>WORLD</strong> that guarantee 100% of your initial deposit through bank endorsement before the client releases any payment.</li>
</ul>
</li>
<li><strong>Attorneys Client Trust Account</strong>
<ul>
<li>Once your agreement is approved by the compliance department, and bank endorsed, the payment is to be made <strong>ONLY AND EXCLUSIVELY</strong> to an<strong> attorney&#8217;s office client trust account</strong>. These banking coordinates will be provided directly from a Hanson Group compliance officer (CCO), and they will be included inside your Invoice.</li>
</ul>
</li>
</ol>
<p>This Refund Deposit  Program protects our clients and makes sure that the deposits are completely safe.</p>
<p><strong>16 Advantages to Purchasing a Leased Bank Proof of Funds from Us!</strong></p>
<ol>
<li><strong>Our program utilizes non-rated for POFs.</strong></li>
<li><strong>We issue POF in EUR and USD.</strong></li>
<li><strong>Offer a leasing rate of 1,5% for Hard Copy and 5% via Swift for a three-month term. </strong></li>
<li><strong>Payment is received after the agreement is bank endorsed. </strong></li>
<li><strong>MT199 or MT999 include Pre-advice Included upon delivery of the POF Delivery</strong></li>
<li><strong>We protect 100 percent of your payment. </strong></li>
<li><strong>No Corporate or personal credit checks. </strong></li>
<li><strong>No documentation is necessary for your project. </strong></li>
<li><strong>After the agreement is completed, it is returned within 72 hours. </strong></li>
<li><strong>We will pay a commission of up to 1.5% to any brokers.</strong></li>
<li><strong>MT199 or MT999 providers deliver to your bank.</strong></li>
<li><strong>Hard Copy POF can be verified in real-time 24/7 on the bank website verification form.</strong></li>
<li><strong>POF developed specifically for client needs. </strong></li>
<li><strong>Performance Penalty of 2 percent in all contracts. </strong></li>
<li><strong>Your deposit is fully protected. </strong></li>
</ol>

<h3><strong>Deposit Requirements for Leased POF</strong></h3>

<div class="table-warp">
<div class="table-responsive">
    <table class="table table-reset table-detail-job table-striped table-bordered">


        <thread>
            <tr>                            
<th>Bank Instrument Face Value</th>
<th>Minimum Deposit Required - Euros</th>
</tr>

        </thread>

        <tbody>

            <tr>                                                            <td>                                                                                                        1 Million (minimum) to 500M                                                             </td>
<td>                                                                                                        5%,  Three-Month Term                                                               </td>
<td>                                                                                                        1,5%,  Three-Month Term                                                                 </td>
<td>                                                                                                        €25,000 - Non Refundable                                                                </td>
</tr>
</tbody>
</table>
</div>
</div>


                    <!--<a class="btn btn-primary py-3 px-5" href="">Go Back To Home</a>-->
                </div>
            </div>
        </div>
    </div>
    <!-- bank End -->

    <?php include 'footer.php'; ?>

    <?php include 'script.php'; ?>