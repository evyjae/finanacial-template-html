<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Fortune Group LLC - Business Loan</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta name="description" content="Fortune Group LLC: Your Trusted Loan Partner Looking for reliable financial assistance? Look no further than Fortune Group LLC. As a leading loan company, we specialize in providing tailored loan solutions to meet your unique needs. Whether you're planning to expand your business, consolidate debts, or fulfill personal aspirations, our team of experts is here to support you.With Fortune Group LLC, you can expect competitive interest rates, flexible repayment terms, and a hassle-free application process. We understand the value of your time, which is why we strive to deliver quick loan approvals, ensuring you get the funds you need when you need them.
" />

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500;600;700&family=Open+Sans:wght@400;500&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;"></div>
    </div>
    <!-- Spinner End -->


    <?php include 'header.php'; ?>

        <!-- Page Header Start -->
    <div class="container-fluid page-header mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container">
            <h1 class="display-3 mb-4 animated slideInDown"> Business Loan</h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                   
                    <li class="breadcrumb-item active" aria-current="page"> Business Loan</li>
                </ol>
            </nav>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- Bank Start -->
    <div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container text-center">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    
                    <h1 class="display-1">Business Loan</h1>
                    <h1 class="mb-6">Business Loan</h1>
                    <p class="mb-6">Business  loan is a loan product offered to business owners who have a running company or who wants to open a new business but require external funds for operations. The investment cover expenses such as employee salaries, rent, buying equipment, acqusition of land/building or expanding the business in other countries/cities.
Our company finance will analyze the business owner's creditworthiness through factors such as credit score and business turnover. However, entrepreneurs or business owners are legally bound to use the loan amount only to cover business expenses and not use the loan amount to cover personal expenditures.
</p>


                    


                    <!--<a class="btn btn-primary py-3 px-5" href="">Go Back To Home</a>-->
                </div>
            </div>
        </div>
    </div>
    <!-- bank End -->

    <?php include 'footer.php'; ?>

    <?php include 'script.php'; ?>