   <!-- Navbar Start -->
    <div class="container-fluid fixed-top px-0 wow fadeIn" data-wow-delay="0.1s">
        <div class="top-bar row gx-0 align-items-center d-none d-lg-flex">
            <div class="col-lg-6 px-5 text-start">
                <small><i class="fa fa-map-marker-alt text-primary me-2"></i>4835 Cordell Avenue, Apt 916. Bethesda, Maryland 20814, USA</small>
                <!--<small class="ms-4"><i class="fa fa-clock text-primary me-2"></i>8.00 am - 4.00 pm</small>-->
            </div>
            <div class="col-lg-6 px-5 text-end">
                <small><i class="fa fa-envelope text-primary me-2"></i>info@fortunegroupsllc.com</small>
                <small class="ms-4"><i class="fa fa-phone-alt text-primary me-2"></i>+1 8605526128</small>
            </div>
        </div>

        <nav class="navbar navbar-expand-lg navbar-light py-lg-0 px-lg-5 wow fadeIn" data-wow-delay="0.1s">
            <a href="index.html" class="navbar-brand ms-4 ms-lg-0">
                <h1 class="display-5 text-primary m-0">Fortune Group</h1>
            </a>
            <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ms-auto p-4 p-lg-0">
                    <a href="index.html" class="nav-item nav-link active">Home</a>
                    <a href="about-us.php" class="nav-item nav-link">About Us</a>
                    
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Services</a>
                        <div class="dropdown-menu border-light m-0">
                            <a href="asset-management.php" class="dropdown-item">Asset Management</a>
                            <a href="pof.php" class="dropdown-item">Bank Proof Of Funds</a>
                            <a href="bank-gurantee.php" class="dropdown-item">Bank Gurantee</a>
                            <a href="letter-of-credit.php" class="dropdown-item">Letter Of Credit</a>
                            <a href="project-finance.php" class="dropdown-item">Project finance</a>
                            <a href="sblc.php" class="dropdown-item">Standby Letter of Credit (SBLC)</a>
                            <a href="monitization.php" class="dropdown-item">Monitization </a>
                            <a href="bank-instrument.php" class="dropdown-item">Bank Instrument</a>
                            <a href="business-loan.php" class="dropdown-item">Business loan</a>
                            <a href="fixed-deposit.php" class="dropdown-item">Fixed Deposit</a>
                            
                        </div>

                         </div>
                   <!-- <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                        <div class="dropdown-menu border-light m-0">
                            <a href="project.html" class="dropdown-item">Projects</a>
                            <a href="feature.html" class="dropdown-item">Features</a>
                            <a href="team.html" class="dropdown-item">Team Member</a>
                            <a href="testimonial.html" class="dropdown-item">Testimonial</a>
                            <a href="404.html" class="dropdown-item">404 Page</a>
                        </div>
                    </div>-->

                     <a href="buy.php" class="nav-item nav-link">Buy</a>
                     <!--<a href="about.html" class="nav-item nav-link">Blog</a>-->
                    <a href="contact-us.php" class="nav-item nav-link">Contact</a>
                    <a href="https://app.fortunegroupsllc.com/user/login" class="btn btn-primary py-3 px-5 mt-3 animated slideInDown">Get Started</a>
                </div>
                <div class="d-none d-lg-flex ms-2">
                    <a class="btn btn-light btn-sm-square rounded-circle ms-3" href="">
                        <small class="fab fa-facebook-f text-primary"></small>
                    </a>
                    <a class="btn btn-light btn-sm-square rounded-circle ms-3" href="">
                        <small class="fab fa-twitter text-primary"></small>
                    </a>
                    <a class="btn btn-light btn-sm-square rounded-circle ms-3" href="">
                        <small class="fab fa-linkedin-in text-primary"></small>
                    </a>
                </div>
            </div>
        </nav>
    </div>
    <!-- Navbar End -->