<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Fortune Group LLC - Bank Instrument</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta name="description" content="Fortune Group LLC: Your Trusted Loan Partner Looking for reliable financial assistance? Look no further than Fortune Group LLC. As a leading loan company, we specialize in providing tailored loan solutions to meet your unique needs. Whether you're planning to expand your business, consolidate debts, or fulfill personal aspirations, our team of experts is here to support you.With Fortune Group LLC, you can expect competitive interest rates, flexible repayment terms, and a hassle-free application process. We understand the value of your time, which is why we strive to deliver quick loan approvals, ensuring you get the funds you need when you need them.
" />

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500;600;700&family=Open+Sans:wght@400;500&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;"></div>
    </div>
    <!-- Spinner End -->


    <?php include 'header.php'; ?>

        <!-- Page Header Start -->
    <div class="container-fluid page-header mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container">
            <h1 class="display-3 mb-4 animated slideInDown"> Bank Instrument</h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                   
                    <li class="breadcrumb-item active" aria-current="page"> Bank Instrument</li>
                </ol>
            </nav>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- Bank Start -->
    <div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container text-center">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    
                    <h1 class="display-1">Bank Instrument</h1>
                    <h1 class="mb-6">Bank Instrument</h1>
                    <p class="mb-6">The company is a leading Financial Services provider that is headquartered in USA and branches in the other countries. We provide Non Recourse Loans, Business Loans, SME Loan, Investment Loan, Project Financing, Bank Guarantees, SBLCs, Letters of Credit, Monetization of BG/SBLC and funding for all kinds of viable projects locally and internationally. All our Bank Instruments come from Top Prime AAA rated banks such as Citibank New York, HSBC USA, Hong Kong 
                    or London, Barclays bank London, Standard Chartered Bank London/Dubai/Hong Kong, UBS Switzerland, Wells-Fargo, Bank of America, Deusche Bank etc. We can help you to obtain financing for your business or projects, activate credit line, Issue & provide Letters of credit, BG or SBLC for you, provide loans against financial instruments, and monetize financial instruments.
<br>
                    We offer our clients services at par with global standards as we represent you with the issuance of commercial whitepaper, bonds, notes and other instruments and securities. We offer you unparalleled support in all matters concerning your bank instruments and securities portfolio. So if for example you place an order to buy a bond or shares, we ensure that we follow the process from when the order is executed on the stock market until it is properly liquidated and deposited into your account. This means our clients are freed up to take the crucial decisions about which investments to make while we handle the post trade process.<br>
                    We represent our clients in the clearing and settlement or exchange of all information for a securities and instruments transaction between two parties. We also handle the settlement of the securities into both the buyers account and the settlement of cash into the sellers account. When the securities are paid for, they are maintained in your account and we process all the incidents that occur and affect the securities contained in your accounts such as coupons or dividends. We monitor both domestic and international markets to collect information related to your assets in our custody. We also ensure that tax claims pertaining to cross border securities are taken care of according to due processes. We stay committed to our clients and take our time to understand every requirement of these instruments so we can continue to offer you solutions that work. We lend focus to post trade services guided by your business goals so we make it easy for you to access and move your assets so they can meet your business needs.<br>

                    Our team of established professionals are available to help you identify the kinds of bank instruments that you may not know about but can be quite instrumental in helping you get a deal or project funded. With our help you can monetize your bank instruments or use them as collateral in exchange for credit thus helping you raise cash equity for running your business. We serve as an intermediary between our clients and the direct bank instruments provider to help you procure the best deals at the right time either on purchase or lease at a minimal cost. We work closely with these providers and they are tested and trusted when it comes to delivering fresh cut bank instruments and securities from highly rated AA banks.  We respect the process of operational management excellence and we work constructively with brokers to ensure we can always provide the instruments our clients need without any stress to them. We hold our team to the highest moral and ethical standards so you can be assured we handle your business as transparently as possible and on time.</p>

                    


                    <!--<a class="btn btn-primary py-3 px-5" href="">Go Back To Home</a>-->
                </div>
            </div>
        </div>
    </div>
    <!-- bank End -->

    <?php include 'footer.php'; ?>

    <?php include 'script.php'; ?>