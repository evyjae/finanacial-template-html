<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Fortune Group LLC - Standby Letter of Credit (SBLC)</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
   <meta name="description" content="Fortune Group LLC: Your Trusted Loan Partner Looking for reliable financial assistance? Look no further than Fortune Group LLC. As a leading loan company, we specialize in providing tailored loan solutions to meet your unique needs. Whether you're planning to expand your business, consolidate debts, or fulfill personal aspirations, our team of experts is here to support you.With Fortune Group LLC, you can expect competitive interest rates, flexible repayment terms, and a hassle-free application process. We understand the value of your time, which is why we strive to deliver quick loan approvals, ensuring you get the funds you need when you need them.
" />

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500;600;700&family=Open+Sans:wght@400;500&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;"></div>
    </div>
    <!-- Spinner End -->


    <?php include 'header.php'; ?>

        <!-- Page Header Start -->
    <div class="container-fluid page-header mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container">
            <h1 class="display-3 mb-4 animated slideInDown"> Standby Letter of Credit (SBLC)</h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                   
                    <li class="breadcrumb-item active" aria-current="page"> Standby Letter of Credit (SBLC)</li>
                </ol>
            </nav>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- Bank Start -->
    <div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container text-center">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    
                    <h1 class="display-1">Standby Letter of Credit (SBLC)</h1>
                    <h1 class="mb-6">Standby Letter of Credit (SBLC)</h1>
                    <p class="mb-6">A Standby Letter of Credit (SBLC) is used for various projects and can be used in global finance, credit enhancement, project finance, trade finance, and many more. It is an amazing opportunity, but you must get access to an investor&#8217;s cash funds, which is where we come into place.</p>

                    <p class="sub-text-career">While acting as an owner, you have the same rights and can use your fund as collateral, place a lien, or even monetize it. This is all available through your term of the leased SBLC or upon renewal of the contract.</p>
<p class="sub-text-career">Our Leased Standby Letter of Credit is an issuance of the World Top 100 Banks and delivered through Bloomberg, Euroclear, DTC screen block and pay, and SWIFT. Banks send this SBLC back and forth through SWIFT MT799 and then SWIFT MT760.</p>

<p><strong>We Protect Our Client Deposits Fully Through 3 Levels of Protection</strong></p>
<p>You never have to worry about your security with our three levels of protection:</p>
<ol>
<li><strong>A Two Percent (2%) Non-Performance Penalty</strong>
<ul class="list-check-icon">
<li>Two Percent (2%) damage fee will apply to a Party that fails to perform. The 2% shall apply in both cases, either when the Provider has sent a Corporate Invoice which the Beneficiary’s Bank will not respond or pay, and/or when the Beneficiary’s Bank is ready, willing, and able to receive the BANK INSTRUMENTS and no BANK INSTRUMENTS is delivered from the Providers Bank by SWIFT MT-760, DTC, Euroclear or Bloomberg.</li>
</ul>
</li>
<li><strong>A Program to Refund Deposits</strong> (all our agreements are Bank Endorsed (<strong>confirmable</strong>) with full bank responsibility as an insurance wrap)
<ul class="list-check-icon">
<li>With our agreement with banks, that bank becomes responsible for payment when the transaction becomes complete.</li>
<li>When a bank endorsed an agreement, the bank becomes responsible before the client pays our company any fees. We are the only Bank Instrument Facilitators in the <strong>WORLD</strong> that guarantee 100% of your initial deposit through bank endorsement before the client releases any payment.</li>
</ul>
</li>
<li><strong>Attorneys Client Trust Account</strong>
<ul class="list-check-icon">
<li>Once your agreement is approved by the compliance department, and bank endorsed, the payment is to be made <strong>ONLY AND EXCLUSIVELY</strong> to an<strong> attorney&#8217;s office client trust account</strong>. These banking coordinates will be provided directly from a Hanson Group compliance officer (CCO), and they will be included inside your Invoice.</li>
</ul>
</li>
</ol>
<p style="margin: 0px 0px 20px; line-height: 24px; color: #777777; font-family: 'Open Sans'; background-color: #ffffff;">This Refund Deposit  Program protects our clients and makes sure that the deposits are completely safe.</p>
<h4><strong>16 Advantages of Purchasing a Leased </strong><strong>Standby Letter of Credit (SBLC) from us!</strong></h4>
<ol>
<li><strong>Our program operates with Top 100 World Banks to secure your </strong><strong>Standby Letter of Credit.</strong></li>
<li><strong>We offer <a href="../financing/index.html">monetization</a> for our own bank instrument in case clients need this service.</strong></li>
<li><strong>SBLC is available in EUR and USD. </strong></li>
<li><strong><b>We offer Low Leasing Rates of 8+2 (10% Total)  for Rated Bank or 5+2 (7% Total) for Non-Rated Bank</b>.</strong></li>
<li><strong>After receiving the MT760, you have 5 days to complete your payment. </strong></li>
<li><strong>Pre-advice for the MT799 is included along with the SBLC.</strong></li>
<li><strong>100 percent protected Deposit. </strong></li>
<li><strong>No Corporate or Personal Credit Checks</strong></li>
<li><strong>No Documentation for your Project Required</strong></li>
<li><strong>Agreement Signed and returned within 72 hours of completion.<br />
</strong></li>
<li><strong>MT760 offers SWIFT delivery to your Bank.</strong></li>
<li><strong>We offer Bloomberg, Euroclear, or DTC delivery to your Bank.</strong></li>
<li><strong>Brokers receive up to 1.5% Commission.</strong></li>
<li><strong>SBLC is specific to each client’s needs. </strong></li>
<li><b>Non-performance penalty of 2 percent included in all contracts. </b></li>
<li><strong>Deposit is 100 % protected, and the Provider Bank endorses client payout</strong></li>
</ol>

<h3><strong>Deposit Requirements for Leased BG&#8217;s via SWIFT: </strong></h3>

<div class="table-warp">
<div class="table-responsive">
    <table class="table table-reset table-detail-job table-striped table-bordered">


        <thread>
            <tr>                            
<th>Bank Instrument Face Value</th>
<th>Minimum Deposit Required - Euros</th>
</tr>

        </thread>

        <tbody>

            <tr>                                                            <td>                                                                                                        €1,000,000.00 (One Million Euros) minimum                                                               </td>
<td>                                                                                                        €35,000.00 (Thirty-Five Thousand Euros)                                                             </td>
</tr>
<tr>                                                            <td>                                                                                                        €2,000,000.00 (Two Million Euros) to €500,000,000.00 (Five Hundred Million Euros)                                                               </td>
<td>                                                                                                        2% of the Bank Instrument Face Value                                                                </td>
</tr>
</tbody>
</table>
</div>
</div>
<p><strong>Prices in EUROS/DOLLARS</strong></p>
<p>Please Note: Leasing process via Swift: 7 banking days.</p>

<strong>Deposit Requirements for Leased BG&#8217;s via EUROCLEAR &amp; BLOOMBERG: </strong>


        <div class="table-warp">
<div class="table-responsive">
    <table class="table table-reset table-detail-job table-striped table-bordered">


        <thread>
            <tr>                            
<th>Bank Instrument Face Value (10 million minimum)</th>
<th>Minimum Deposit Required - Euros</th>
</tr>

        </thread>

        <tbody class="wpsm-tbody">
<tr>                                                            <td>                                                                                                        €10,000,000.00 (Ten Million Euros)                                                              </td>
<td>                                                                                                        €75,000.00 (Seventy Five Thousand euros)                                                                </td>
</tr>
<tr>                                                            <td>                                                                                                        €20,000,000.00 (Twenty Million Euros)                                                               </td>
<td>                                                                                                        €100,000.00 (One Hundred Thousand euros)                                                                </td>
</tr>
<tr>                                                            <td>                                                                                                        €30,000,000.00 (Thirty Million Euros)                                                               </td>
<td>                                                                                                        €125,000.00 (One Hundred and Twenty-Five Thousand euros)                                                                </td>
</tr>
<tr>                                                            <td>                                                                                                        €40,000,000.00 (Forty Million Euros)                                                                </td>
<td>                                                                                                        €150,000.00 (One Hundred and Fifty Thousand euros)                                                              </td>
</tr>
<tr>                                                            <td>                                                                                                        €50,000,000.00 (Fifty Million Euros)                                                                </td>
<td>                                                                                                        €175,000.00 (One Hundred and Seventy-Five Thousand euros)                                                               </td>
</tr>
<tr>                                                            <td>                                                                                                        €60,000,000.00 (Sixty Million Euros)                                                                </td>
<td>                                                                                                        €200,000.00 (Two Hundred Thousand euros)                                                                </td>
</tr>
<tr>                                                            <td>                                                                                                        €70,000,000.00 (Seventy Million Euros)                                                              </td>
<td>                                                                                                        €225,000.00 (Two Hundred and Twenty-Five Thousand euros)                                                                </td>
</tr>
<tr>                                                            <td>                                                                                                        €80,000,000.00 (Eighty Million Euros)                                                               </td>
<td>                                                                                                        €250,000.00 (Two Hundred and Fifty Thousand euros)                                                              </td>
</tr>
<tr>                                                            <td>                                                                                                        €90,000,000.00 (Ninety Million Euros)                                                               </td>
<td>                                                                                                        €275,000.00 (Two Hundred and Seventy-Five Thousand euros)                                                               </td>
</tr>
<tr>                                                            <td>                                                                                                        €100,000,000.00 (One Hundred Million Euros)                                                             </td>
<td>                                                                                                        €300,000.00 (Three Hundred Thousand euros)                                                              </td>
</tr>
<tr>                                                            <td>                                                                                                        €150,000,000.00 (One Hundred and Fifty Million Euros)                                                               </td>
<td>                                                                                                        €325,000.00 (Three Hundred and Twenty-Five Thousand euros)                                                              </td>
</tr>
<tr>                                                            <td>                                                                                                        €200,000,000.00 (Two Hundred Million Euros)                                                             </td>
<td>                                                                                                        €350,000.00 (Three Hundred and Fifty Thousand euros)                                                                </td>
</tr>
<tr>                                                            <td>                                                                                                        €250,000,000.00 (Two Hundred and Fifty Million Euros)                                                               </td>
<td>                                                                                                        €375,000.00 (Three Hundred and Seventy-Five Thousand euros)                                                             </td>
</tr>
<tr>                                                            <td>                                                                                                        €300,000,000.00 (Three Hundred Million Euros)                                                               </td>
<td>                                                                                                        €400,000.00 (Four Hundred Thousand Thousand euros)                                                              </td>
</tr>
<tr>                                                            <td>                                                                                                        €350,000,000.00 (Three Hundred and Fifty Million Euros)                                                             </td>
<td>                                                                                                        €425,000.00 (Four Hundred and Twenty-Five Thousand euros)                                                               </td>
</tr>
<tr>                                                            <td>                                                                                                        €400,000,000.00 (Four Hundred Million Euros)                                                                </td>
<td>                                                                                                        €450,000.00 (Four Hundred and Fifty Thousand euros)                                                             </td>
</tr>
<tr>                                                            <td>                                                                                                        €450,000,000.00 (Four Hundred and Fifty Million Euros)                                                              </td>
<td>                                                                                                        €475,000.00 (Four Hundred and Seventy-Five Thousand euros)                                                              </td>
</tr>
<tr>                                                            <td>                                                                                                        €500,000,000.00 (Five Hundred Million Euros)                                                                </td>
<td>                                                                                                        €500,000.00 (Five Hundred Thousand euros)                                                               </td>
</tr>
</tbody>
</table>
</div>
</div>


                    <!--<a class="btn btn-primary py-3 px-5" href="">Go Back To Home</a>-->
                </div>
            </div>
        </div>
    </div>
    <!-- bank End -->

    <?php include 'footer.php'; ?>

    <?php include 'script.php'; ?>