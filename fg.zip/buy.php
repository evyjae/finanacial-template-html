<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Fortune Group LLC - Buy</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
     <meta name="description" content="Fortune Group LLC: Your Trusted Loan Partner Looking for reliable financial assistance? Look no further than Fortune Group LLC. As a leading loan company, we specialize in providing tailored loan solutions to meet your unique needs. Whether you're planning to expand your business, consolidate debts, or fulfill personal aspirations, our team of experts is here to support you.With Fortune Group LLC, you can expect competitive interest rates, flexible repayment terms, and a hassle-free application process. We understand the value of your time, which is why we strive to deliver quick loan approvals, ensuring you get the funds you need when you need them.
" />

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500;600;700&family=Open+Sans:wght@400;500&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;"></div>
    </div>
    <!-- Spinner End -->


    <?php include 'header.php'; ?>

        <!-- Page Header Start -->
    <div class="container-fluid page-header mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container">
            <h1 class="display-3 mb-4 animated slideInDown"> Buy</h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                   
                    <li class="breadcrumb-item active" aria-current="page"> Buy</li>
                </ol>
            </nav>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- Bank Start -->
    <div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container text-center">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    
                    <h1 class="display-1">Buy</h1>
                    <h1 class="mb-6">Buy</h1>
                    <p class="mb-6">The company can help obtain financing, activate credit lines, provide loans against financial instruments, and monetize financial instruments.</p>
<p>The word Financing under a magnifying glass with terms like interest rate, loan, borrow, bank, qualify, options, down payment, equity, mortgage, and collateral.</p>

                    <p>Our company can offer the most competitive terms when rendering assistance in obtaining financing for commercial transactions and various business projects. Every project that requires financing will be discussed on an individual basis. Our loans have an interest rate of 2% per annum with up to 4 years of grace and can span up to ten years in length.</p>
<p class="sub-text-career">To obtain debt financing, our company uses the active credit lines of our partners. We are prompt with flexible conditions financing against the most spread types of financial instruments such as:</p>
<p><a href="bank-gurantee.php">Bank Guarantee (BG)</a><br />
<a href="sblc">Standby Letters of Credit (SBLC)</a><br />
<a href="cd.php">Certificate of Deposit (CD)</a><br />
<a href="mtn.php">Medium Term Note (MTN)</a><br />
<a href="bank-draft.php">Bank Draft</a> and others.</p>
<p>This type of financing imposes less rigid requirements to the current financial status of the client and quality of a financial project than traditional project financing.</p>

<p class="sub-text-career"><strong>Loans with Bank Instruments as collateral LTV: </strong></p>
<ul>
<li>10M to 500M &#8211; 45% Non-Rated Bank or 65% Rated Bank &#8211; Non-Recourse Loan</li>
<li>10M to 500M Bank Guarantee (BG) &#8211; 65% Recourse Loan with a Non-Rated Bank instrument or 80% Recourse Loan with a Rated Bank instrument – This loan has an interest rate of 2% per annum with up to 4 years of grace and can span up to ten years in length.</li>
</ul>
<p class="sub-text-career"><strong>Estimated Completion Time:</strong></p>
<ul>
<li>7 to 14 days after all documents are signed and verified or 5 to 7 Days After Instrument Delivery on the SWIFT, Euroclear, or DTCC Networks.</li>
</ul>
<p class="sub-text-career"><strong>Loan Disbursement:</strong></p>
<ol>
<li>21 days after confirmation and authentication of the MT-760, we release the first disbursement (20% of the loan).</li>
<li>30 days after the first disbursement, we release the second disbursement (20% of the loan).</li>
<li>The remaining 60% of the loan will be divided into ten (10) months and will be disbursed every 30 days after the second disbursement.</li>
</ol>
<p class="sub-text-career"><strong>Notes:</strong></p>
<ul>
<li>Full loan disbursement in 12 months.</li>
<li>In case of client does not have a bank instrument to place as collateral for the project, Hanson Group can offer to lease the bank instrument to the client and at the same time offers the monetization.</li>
<li>Hanson Group can monetize a bank instrument via our attorney&#8217;s trustees with a minimum face value of 10M and up to 500M maximum per tranche.</li>
<li>If the client is leasing the bank instrument from Hanson Group, the client only has to pay for the initial deposit fees, and the attorney-trustee office will pay for the lease instrument cost if your loan is approved.</li>
<li>Loan approval is most likely to be approved since you are leasing the bank instrument from us. However, the attorney&#8217;s trustee office reserves the right to provide a loan or NOT to a client.</li>
</ul>
<h4><strong>Recourse Loan Disbursements Example (100 Million Euros):</strong></h4>
<p class="sub-text-career">Bank instrument face value: €100,000,000.00<br />
Recourse Loan disbursement (80%): €80,000,000.00<br />
Loan commission fees (5%): €4,000,000.00</p>
<h4><em>Total Loan Disbursement: €76,000,000.00</em></h4>
<h4><strong>Example of Recourse Loan Disbursement Schedule:</strong></h4>

                    <!--<a class="btn btn-primary py-3 px-5" href="">Go Back To Home</a>-->
                </div>
            </div>
        </div>
    </div>
    <!-- bank End -->

    <?php include 'footer.php'; ?>

    <?php include 'script.php'; ?>