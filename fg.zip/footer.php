    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-light footer mt-5 py-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-4">Our Office</h4>
                    <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>4835 Cordell Avenue, Apt 916. Bethesda, Maryland 20814, USA</p>
                    <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+1 8605526128</p>
                    <p class="mb-2"><i class="fa fa-envelope me-3"></i>info@fortunegroupsllc.com</p>
                    <div class="d-flex pt-2">
                        <a class="btn btn-square btn-outline-light rounded-circle me-2" href=""><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-square btn-outline-light rounded-circle me-2" href=""><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-square btn-outline-light rounded-circle me-2" href=""><i class="fab fa-youtube"></i></a>
                        <a class="btn btn-square btn-outline-light rounded-circle me-2" href=""><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-4">Services</h4>
                    <a class="btn btn-link" href="asset-management.php">Asset Management </a>
                    <a class="btn btn-link" href="pof.php">Bank Proof Of Funds </a>
                    <a class="btn btn-link" href="bank-gurantee.php">Bank Gurantee </a>
                    <a class="btn btn-link" href="letter-of-credit.php">Letter Of Credit </a>
                    <a class="btn btn-link" href="bank-instrument.php">Bank Instrument </a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-4">Quick Links</h4>
                    <a class="btn btn-link" href="about-us.php">About Us</a>
                    <a class="btn btn-link" href="contact-us.php">Contact Us</a>
                    <a class="btn btn-link" href="monitization.php">Monitization </a>
                    <a class="btn btn-link" href="sblc.php">Standby Letter of Credit (SBLC)</a>
                    <a class="btn btn-link" href="mailto:info@fortunegroupsllc.com">Support</a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-4">Newsletter</h4>
                    <p>Get latest news from us by subscribing to our weekly newsletter</p>
                    <div class="position-relative w-100">
                        <input class="form-control bg-white border-0 w-100 py-3 ps-4 pe-5" type="text" placeholder="Your email">
                        <button type="button" class="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2">SignUp</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Copyright Start -->
    <div class="container-fluid copyright py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                    &copy; <a class="border-bottom" href="#">2023 Fortune Group</a>, All Right Reserved.
                </div>
                <!--<div class="col-md-6 text-center text-md-end">
                   
                    Designed By <a class="border-bottom" href="https://htmlcodex.com">HTML Codex</a>-->
                </div>
            </div>
        </div>
    </div>
    <!-- Copyright End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded-circle back-to-top"><i class="bi bi-arrow-up"></i></a>
